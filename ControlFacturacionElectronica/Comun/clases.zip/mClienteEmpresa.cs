﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace ReadCFDI
{
    class mClienteEmpresa
    {
            string connString;
    	    int IDClienteEmpresa {get; set;}
	        int IDEmpresa {get; set;}
	        string NombreComercial {get; set;}
	        string NombreContacto {get; set;}
	        string RazonSocial {get; set;}
	        string RFC  {get; set;}
	        string DomicilioFiscal_calle {get; set;}
	        string DomicilioFiscal_noExterior {get; set;}
	        string DomicilioFiscal_colonia {get; set;}
	        string DomicilioFiscal_localidad {get; set;}
	        string DomicilioFiscal_municipio {get; set;}
	        string DomicilioFiscal_estado {get; set;}
	        string DomicilioFiscal_pais {get; set;}
	        string DomicilioFiscal_codigoPostal {get; set;}
	        string CorreoEletronico {get; set;}
	        string ContactoTelefono {get; set;}
	        string ContactoCelular {get; set;}
	        string TipoPersona {get; set;}

            mEmpresa objEmpresa;

        public mClienteEmpresa(string connString) 
        {
            this.connString = connString;

        }

        public mClienteEmpresa(string connString, int idClienteEmpresa) 
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@idEmpresa", idClienteEmpresa);
            DataTable dt = SqlHelper.ExecuteDataset(this.connString, CommandType.StoredProcedure, "", param).Tables[0];

            this.IDClienteEmpresa = Convert.ToInt32(dt.Rows[0]["IDClienteEmpresa"].ToString());
            this.IDEmpresa = Convert.ToInt32(dt.Rows[0]["IDEmpresa"].ToString());
            this.NombreComercial = dt.Rows[0]["NombreComercial"].ToString();
            this.NombreContacto = dt.Rows[0]["NombreContacto"].ToString();
            this.RazonSocial = dt.Rows[0]["RazonSocial"].ToString();
            this.RFC = dt.Rows[0]["RFC"].ToString();
            this.DomicilioFiscal_calle = dt.Rows[0]["DomicilioFiscal_calle"].ToString();
            this.DomicilioFiscal_noExterior = dt.Rows[0]["DomicilioFiscal_noExterior"].ToString();
            this.DomicilioFiscal_colonia = dt.Rows[0]["DomicilioFiscal_colonia"].ToString();
            this.DomicilioFiscal_localidad = dt.Rows[0]["DomicilioFiscal_localidad"].ToString();
            this.DomicilioFiscal_municipio = dt.Rows[0]["DomicilioFiscal_municipio"].ToString();
            this.DomicilioFiscal_estado = dt.Rows[0]["DomicilioFiscal_estado"].ToString();
            this.DomicilioFiscal_pais = dt.Rows[0]["DomicilioFiscal_pais"].ToString();
            this.DomicilioFiscal_codigoPostal = dt.Rows[0]["DomicilioFiscal_codigoPostal"].ToString();
            this.CorreoEletronico = dt.Rows[0]["CorreoEletronico"].ToString();
            this.ContactoTelefono = dt.Rows[0]["ContactoTelefono"].ToString();
            this.ContactoCelular = dt.Rows[0]["ContactoCelular"].ToString();
            this.TipoPersona = dt.Rows[0]["TipoPersona"].ToString();

        }


        public int insertEmpresa() 
        {
            try
            {
                SqlParameter[] param = new SqlParameter[16];
                param[0] = new SqlParameter("@NombreComercial", this.NombreComercial);
                param[1] = new SqlParameter("@NombreContacto", this.NombreContacto);
                param[2] = new SqlParameter("@RazonSocial", this.RazonSocial);
                param[3] = new SqlParameter("@RFC", this.RFC);
                param[4] = new SqlParameter("@DomicilioFiscal_calle", this.DomicilioFiscal_calle);
                param[5] = new SqlParameter("@DomicilioFiscal_noExterior", this.DomicilioFiscal_noExterior);
                param[6] = new SqlParameter("@DomicilioFiscal_colonia", this.DomicilioFiscal_colonia);
                param[7] = new SqlParameter("@DomicilioFiscal_localidad", this.DomicilioFiscal_localidad);
                param[8] = new SqlParameter("@DomicilioFiscal_municipio", this.DomicilioFiscal_municipio);
                param[9] = new SqlParameter("@DomicilioFiscal_estado", this.DomicilioFiscal_estado);
                param[10] = new SqlParameter("@DomicilioFiscal_pais", this.DomicilioFiscal_pais);
                param[11] = new SqlParameter("@DomicilioFiscal_codigoPostal", this.DomicilioFiscal_codigoPostal);
                param[12] = new SqlParameter("@CorreoEletronico", this.CorreoEletronico);
                param[13] = new SqlParameter("@ContactoTelefono", this.ContactoTelefono);
                param[14] = new SqlParameter("@ContactoCelular", this.ContactoCelular);
                param[15] = new SqlParameter("@TipoPersona", this.TipoPersona);

                return SqlHelper.ExecuteNonQuery(connString, CommandType.StoredProcedure, "", param);
            }
            catch (Exception e) 
            {
                return 0;
            }
        }

        public DataTable getClienteEmpresabyID(int id) 
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@idEmpresa", id);
            return SqlHelper.ExecuteDataset(connString, CommandType.StoredProcedure, "", param).Tables[0];
        }


        public DataTable getClienteEmpresabyID(string rfc)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RFC", rfc);
            return SqlHelper.ExecuteDataset(connString, CommandType.StoredProcedure, "", param).Tables[0];
        }


        public int updateClienteEmpresa()
        {
            try
            {
                SqlParameter[] param = new SqlParameter[16];
                param[0] = new SqlParameter("@NombreComercial", this.NombreComercial);
                param[1] = new SqlParameter("@NombreContacto", this.NombreContacto);
                param[2] = new SqlParameter("@RazonSocial", this.RazonSocial);
                param[3] = new SqlParameter("@RFC", this.RFC);
                param[4] = new SqlParameter("@DomicilioFiscal_calle", this.DomicilioFiscal_calle);
                param[5] = new SqlParameter("@DomicilioFiscal_noExterior", this.DomicilioFiscal_noExterior);
                param[6] = new SqlParameter("@DomicilioFiscal_colonia", this.DomicilioFiscal_colonia);
                param[7] = new SqlParameter("@DomicilioFiscal_localidad", this.DomicilioFiscal_localidad);
                param[8] = new SqlParameter("@DomicilioFiscal_municipio", this.DomicilioFiscal_municipio);
                param[9] = new SqlParameter("@DomicilioFiscal_estado", this.DomicilioFiscal_estado);
                param[10] = new SqlParameter("@DomicilioFiscal_pais", this.DomicilioFiscal_pais);
                param[11] = new SqlParameter("@DomicilioFiscal_codigoPostal", this.DomicilioFiscal_codigoPostal);
                param[12] = new SqlParameter("@CorreoEletronico", this.CorreoEletronico);
                param[13] = new SqlParameter("@ContactoTelefono", this.ContactoTelefono);
                param[14] = new SqlParameter("@ContactoCelular", this.ContactoCelular);
                param[15] = new SqlParameter("@TipoPersona", this.TipoPersona);
                param[16] = new SqlParameter("@IDClienteEmpresa", this.IDClienteEmpresa);
                param[16] = new SqlParameter("@IDEmpresa", this.IDEmpresa);

                return SqlHelper.ExecuteNonQuery(connString, CommandType.StoredProcedure, "", param);
            }
            catch (Exception e)
            {
                return 0;
            }
        }



    }
}
