﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace ReadCFDI
{
    class mUsuario
    {
        string connString;

        int IDUsuario { set; get; }
        int IDEmpresa { set; get; }
        int IDClienteEmpresa { set; get; }
        string Nombre { set; get; }
        string NombreCuenta { set; get; }
        string Clave { set; get; }

        DataTable dtUserdata;

        mEmpresa objEmpresa;
        mClienteEmpresa objClienteEmpresa;
        mFactura objFactura;

        public mUsuario(string conn) 
        {
            this.connString = conn;

        }


        public mUsuario(string conn, int idEmpresa)
        {
            this.connString = conn;
            objEmpresa = new mEmpresa(conn, idEmpresa);
            objFactura = new mFactura(conn);
        }


        public mUsuario(string conn, int idClienteEmpresa)
        {
            this.connString = conn;
            objClienteEmpresa = new mClienteEmpresa(conn, idClienteEmpresa);
            objFactura = new mFactura(conn);
        }

        public mUsuario(string conn,int idEmpresa, int idClienteEmpresa)
        {
            this.connString = conn;
            objClienteEmpresa = new mClienteEmpresa(conn, idClienteEmpresa);
            objEmpresa = new mEmpresa(conn, idClienteEmpresa);
            objFactura = new mFactura(conn);
        }

        public mUsuario(string conn, int idEmpresa, int idClienteEmpresa, DataTable dtUserdata)
        {
            this.connString = conn;
            this.dtUserdata = dtUserdata;
            objClienteEmpresa = new mClienteEmpresa(conn, idClienteEmpresa);
            objEmpresa = new mEmpresa(conn, idClienteEmpresa);
            objFactura = new mFactura(conn);
        }

        public mUsuario(string conn, string nombreCuenta, string Clave) 
        {
            this.connString = conn;
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@NombreCuenta", nombreCuenta);
            param[1] = new SqlParameter("@Clave", Clave);
            DataTable dt = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "", param).Tables[0];

            this.IDUsuario = Convert.ToInt32(dt.Rows[0]["IDUsuario"].ToString());
            this.IDEmpresa = Convert.ToInt32(dt.Rows[0]["IDEmpresa"].ToString());
            this.IDClienteEmpresa = Convert.ToInt32(dt.Rows[0]["IDClienteEmpresa"].ToString());
            this.Nombre = dt.Rows[0]["Nombre"].ToString();
            this.NombreCuenta = dt.Rows[0]["NombreCuenta"].ToString();
            this.Clave = dt.Rows[0]["NombreCuenta"].ToString();
            objClienteEmpresa = new mClienteEmpresa(conn, this.IDClienteEmpresa);
            objEmpresa = new mEmpresa(conn, this.IDEmpresa);
            objFactura = new mFactura(conn);

        }

        public static mUsuario logging(string conn,string nombreCuenta, string Clave) 
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@NombreCuenta", nombreCuenta);
            param[1] = new SqlParameter("@Clave", Clave);
            DataTable dt = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "", param).Tables[0];

            if (dt.Rows.Count > 0) 
            {
                
                mUsuario user = new mUsuario(conn,Convert.ToInt32(dt.Rows[0]["IDEmpresa"].ToString()),Convert.ToInt32(dt.Rows[0]["IDClienteEmpresa"].ToString()),dt);

                return user;
            }
            else
            {
                return null;
            }

        
        }

        public bool insertUsuario() 
        {
            int result;
            try
            {
                SqlParameter[] param = new SqlParameter[2];
                param[0] = new SqlParameter("@IDEmpresa", this.IDEmpresa);
                param[0] = new SqlParameter("@IDClienteEmpresa", this.IDClienteEmpresa);
                param[0] = new SqlParameter("@Nombre", this.Nombre);
                param[0] = new SqlParameter("@NombreCuenta", this.NombreCuenta);
                param[1] = new SqlParameter("@Clave", this.Clave);
                result = SqlHelper.ExecuteNonQuery(this.connString, CommandType.StoredProcedure, "", param);
            }
            catch (Exception e) 
            {
                result = 0;
            }

            return result;
        
        }


        

    }
}
